﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Contracts
{
    public interface ISpy
    {
        public int CodeNumber { get; }

    }
}
