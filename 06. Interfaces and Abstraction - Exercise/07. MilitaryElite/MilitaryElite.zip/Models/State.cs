﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Models
{
    public enum State
    {
        inProgress = 1,
        Finished =2
    }
}
